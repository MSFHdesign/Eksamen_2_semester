
document.getElementById('rights').innerHTML = '<p> Copyright &copy; ' + new Date().getFullYear() + ' Brainiacs';