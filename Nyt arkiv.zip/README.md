# Eksamen_2_semester
 Eksamens til 2 semester, med Mie, Gerda, Henrik og Michael
